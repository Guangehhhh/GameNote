#@这是对SGI STL源码剖析;
